class CategoryModel{
  String title;
  String imageURL;


}