import 'package:flutter/material.dart';

class Artical extends StatefulWidget {
  @override
  _ArticalState createState() => _ArticalState();
}

class _ArticalState extends State<Artical> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
